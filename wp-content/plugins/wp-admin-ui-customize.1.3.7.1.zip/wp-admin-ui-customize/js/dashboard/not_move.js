jQuery(document).ready(function($) {

	$( ".meta-box-sortables" ).sortable( "disable" );
	$( ".postbox .hndle" ).css( "cursor" , "pointer" );

});
