<?php

if( !empty( $_POST["update"] ) ) {
	$this->update_admin_bar_menu();
} elseif( !empty( $_POST["reset"] ) ) {
	$this->update_reset( 'admin_bar_menu' );
}

$Data = $this->get_data( 'admin_bar_menu' );
$AllDefaultNodes = $this->admin_bar_filter_load();

// include js css
$ReadedJs = array( 'jquery' , 'jquery-ui-draggable' , 'jquery-ui-droppable' , 'jquery-ui-sortable' , 'thickbox' );
wp_enqueue_script( $this->PageSlug ,  $this->Dir . dirname( dirname( plugin_basename( __FILE__ ) ) ) . '.js', $ReadedJs , $this->Ver );
wp_enqueue_style( 'thickbox' );
wp_enqueue_style( $this->PageSlug , $this->Dir . dirname( dirname( plugin_basename( __FILE__ ) ) ) . '.css', array() , $this->Ver );

?>

<div class="wrap">
	<div class="icon32" id="icon-tools"></div>
	<?php echo $this->Msg; ?>
	<h2><?php _e( 'Admin Bar Menu' , $this->ltd ); ?></h2>
	<p><?php _e( 'Please change the menu by drag and drop.' , $this->ltd ); ?></p>
	<p><strong><?php _e( 'Notice: Please do not place the same multiple menu slug.' , $this->ltd ); ?></strong></p>
	<p class="description"><?php _e( 'Can be more than one custom menu.' , $this->ltd ); ?></p>

	<h3 id="wauc-apply-user-roles"><?php echo $this->get_apply_roles(); ?></h3>

	<p><a href="#TB_inline?height=300&width=600&inlineId=list_variables&modal=false" title="<?php _e( 'Shortcodes' , $this->ltd ); ?>" class="thickbox"><?php _e( 'Available Shortcodes' , $this->ltd ); ?></a></p>

	<form id="wauc_setting_admin_bar_menu" class="wauc_form" method="post" action="">
		<input type="hidden" name="<?php echo $this->UPFN; ?>" value="Y" />
		<?php wp_nonce_field( $this->Nonces["value"] , $this->Nonces["field"] ); ?>

		<div id="poststuff">
			<div id="post-body" class="metabox-holder columns-2">

				<div id="postbox-container-1" class="postbox-container">
					<div id="right_menus">
						<?php echo $this->set_setting_admin_bar( 'right' , $Data ); ?>
					</div>
				</div>
				
				<div id="postbox-container-2" class="postbox-container">
					<div id="left_menus">
						<?php echo $this->set_setting_admin_bar( 'left' , $Data ); ?>
					</div>
				</div>
				
				<br class="clear">
			</div>
		</div>

		<div id="can_menus" class="metabox-holder columns-1">

			<div class="postbox">
				<h3 class="hndle"><span><?php _e ( 'Menu items that can be added' , $this->ltd ); ?></span></h3>
				<div class="inside">

					<h4><?php _e( 'Custom' ); ?> <?php _e( 'Menus' ); ?></h4>
					<?php $menu_widget = array( 'id' => "custom_node" , 'title' => "" , 'parent' => '' , 'href' => "" , 'group' => false , 'new' => true , 'subnode' => false ); ?>
					<?php echo $this->admin_bar_menu_widget( $menu_widget ); ?>
					<div class="clear"></div>
					
					<h4><?php _e( 'Left' ); ?> <?php _e( 'Menus' ); ?></h4>

					<?php foreach( $AllDefaultNodes["left"]["main"] as $node_id => $node ) : ?>

						<p class="description"><?php echo $node_id; ?></p>
						<?php $menu_widget = array( 'id' => $node->id , 'title' => $node->title , 'parent' => '' , 'href' => $node->href , 'group' => false , 'new' => true , 'subnode' => false ); ?>
						<?php echo $this->admin_bar_menu_widget( $menu_widget ); ?>

							<?php foreach( $AllDefaultNodes["left"]["sub"] as $child_node_id => $child_node ) : ?>

								<?php if( $child_node->parent == $node_id ) : ?>

									<?php $menu_widget = array( 'id' => $child_node->id , 'title' => $child_node->title , 'parent' => '' , 'href' => $child_node->href , 'group' => false , 'new' => true , 'subnode' => false ); ?>
									<?php echo $this->admin_bar_menu_widget( $menu_widget ); ?>

								<?php endif; ?>

							<?php endforeach; ?>

							<div class="clear"></div>

					<?php endforeach; ?>
					
					<div class="clear"></div>

					<h4><?php _e( 'Right' ); ?> <?php _e( 'Menus' ); ?></h4>

					<?php foreach( $AllDefaultNodes["right"]["main"] as $node_id => $node ) : ?>

						<p class="description"><?php echo $node_id; ?></p>
						<?php $menu_widget = array( 'id' => $node->id , 'title' => $node->title , 'parent' => '' , 'href' => $node->href , 'group' => false , 'new' => true , 'subnode' => false ); ?>
						<?php echo $this->admin_bar_menu_widget( $menu_widget ); ?>
							
						<?php foreach( $AllDefaultNodes["right"]["sub"] as $child_node_id => $child_node ) : ?>

							<?php if( $child_node->parent == $node_id ) : ?>

								<?php $menu_widget = array( 'id' => $child_node->id , 'title' => $child_node->title , 'parent' => '' , 'href' => $child_node->href , 'group' => false , 'new' => true , 'subnode' => false ); ?>
								<?php echo $this->admin_bar_menu_widget( $menu_widget ); ?>

							<?php endif; ?>

						<?php endforeach; ?>
							
						<div class="clear"></div>

					<?php endforeach; ?>
					
					<div class="clear"></div>

				</div>
			</div>

		</div>

		<p class="submit">
			<input type="submit" class="button-primary" name="update" value="<?php _e( 'Save' ); ?>" />
		</p>

		<p class="submit reset">
			<span class="description"><?php _e( 'Reset all settings?' , $this->ltd ); ?></span>
			<input type="submit" class="button-secondary" name="reset" value="<?php _e('Reset'); ?>" />
		</p>

	</form>

</div>

<?php require_once( dirname( __FILE__ ) . '/list_variables.php' ); ?>

<style>
#wauc_setting_admin_bar_menu .postbox .inside .widget.wp-logo .widget-top .widget-title h4 .ab-icon,
#wauc_setting_admin_bar_menu .postbox .inside .widget.updates .widget-top .widget-title h4 .ab-icon,
#wauc_setting_admin_bar_menu .postbox .inside .widget.comments .widget-top .widget-title h4 .ab-icon,
#wauc_setting_admin_bar_menu .postbox .inside .widget.new-content .widget-top .widget-title h4 .ab-icon
{ background-image: url(../wp-includes/images/admin-bar-sprite.png); }
</style>

<script type="text/javascript">
jQuery(document).ready(function($) {

	var $Form = $("#wauc_setting_admin_bar_menu");
	var $AddInside = $('#can_menus .postbox .inside', $Form);
	var $SettingInside = $('#poststuff #post-body .postbox-container .postbox .inside', $Form);

	$AddInside.children('.widget').draggable({
		connectToSortable: '#poststuff #post-body .postbox-container .postbox .inside',
		handle: '> .widget-top > .widget-title',
		distance: 2,
		helper: 'clone',
		zIndex: 5,
		containment: 'document',
		stop: function(e,ui) {
			widget_each();
			menu_sortable();
		}
	});

	$('.columns-1', $Form).droppable({
		tolerance: 'pointer',
		accept: function(o){
			return $(o).parent().parent().parent().parent().parent().parent().parent().attr('class') != 'columns-1';
		},
		drop: function(e,ui) {
			ui.draggable.addClass('deleting');
		},
		over: function(e,ui) {
			ui.draggable.addClass('deleting');
			$('div.widget-placeholder').hide();
		},
		out: function(e,ui) {
			ui.draggable.removeClass('deleting');
			$('div.widget-placeholder').show();
		}
	});


	var $AvailableAction = $('#poststuff #post-body .postbox-container .postbox .inside .widget .widget-top .widget-title-action a[href=#available]', $Form);
	$AvailableAction.live( 'click', function() {
		$(this).parent().parent().parent().children(".widget-inside").slideToggle();
		return false;
	});

	var $RemoveAction = $('#poststuff #post-body .postbox-container .postbox .inside .widget .widget-inside .widget-control-actions .alignleft a[href=#remove]', $Form);
	$RemoveAction.live( 'click', function() {
		$(this).parent().parent().parent().parent().slideUp("normal", function() { $(this).remove(); } );
		return false;
	});

	var menu_sortable = function menu_sortable() {

		$('#wauc_setting_admin_bar_menu #poststuff #post-body .postbox-container .postbox .inside, #wauc_setting_admin_bar_menu #poststuff #post-body .postbox-container .postbox .inside .widget .widget-inside .submenu').sortable({
			placeholder: "widget-placeholder",
			items: '> .widget',
			connectWith: "#wauc_setting_admin_bar_menu #poststuff #post-body .postbox-container .postbox .inside, #wauc_setting_admin_bar_menu #poststuff #post-body .postbox-container .postbox .inside .widget .widget-inside .submenu",
			handle: '> .widget-top > .widget-title',
			cursor: 'move',
			distance: 2,
			containment: 'document',
			change: function(e,ui) {
				var $height = ui.helper.height();
				$('#wauc_setting_admin_bar_menu #poststuff #post-body .postbox-container .postbox .inside .widget-placeholder').height($height);
			},
			stop: function(e,ui) {
				if ( ui.item.hasClass('deleting') ) {
					ui.item.remove();
				}
				widget_each();
			},
		});

	}
	$('#poststuff #post-body').mouseenter(function() {
		menu_sortable();
	});
	menu_sortable();

	function widget_each() {
		var $Count = 0;
		$('#wauc_setting_admin_bar_menu #poststuff #post-body .postbox-container .postbox .inside .widget').each(function() {
			var $InputId = $(this).children(".widget-inside").children(".settings").children(".description").children(".idtext");
			var $InputLink = $(this).children(".widget-inside").children(".settings").children(".description").children(".linktext");
			var $InputTitle = $(this).children(".widget-inside").children(".settings").children("label").children(".titletext");
			var $InputParentName = $(this).children(".widget-inside").children(".settings").children(".parent");

			var $BoxName = "";
			if( $(this).parent().hasClass("submenu") ) {
				$BoxName = $(this).parent().parent().parent().parent().parent().parent().attr("id");
			} else {
				$BoxName = $(this).parent().parent().parent().attr("id");
			}
			
			if( $BoxName ) {
				var $BarType = $BoxName.replace( '_menus' , '');
			}

			if( $(this).hasClass("custom_node") ) {
				var $CustomVal = $InputId.val();
				$InputId.val( $CustomVal + Math.ceil( Math.random() * 1000 ) );
			} else if( $(this).hasClass("newcustom_node") ) {
				var $CustomVal = $InputId.val();
				var $CustomClassName = $CustomVal + Math.ceil( Math.random() * 1000 );
				$InputId.val( $CustomClassName );
				$(this).removeClass("newcustom_node");
				$(this).addClass( $CustomClassName );
			}

			var $Name = 'data' + '[' + $BarType + ']['+$Count+']';
			$InputId.attr("name", $Name+'[id]');
			$InputLink.attr("name", $Name+'[href]');
			$InputTitle.attr("name", $Name+'[title]');
			$InputParentName.attr("name", $Name+'[parent]');

			if ( $(this).parent().parent().parent().parent().hasClass("submenu") ) {
				// None three
				$(this).remove();
			} else if ( $(this).parent().hasClass("submenu") ) {
				var $ParentId = $(this).parent().parent().children(".settings").children(".description").children(".idtext").val();
				$InputParentName.val($ParentId);
			} else {
				$InputParentName.val('');
			}

			$Count++;
		});
	}
	widget_each();
		
});
</script>