=== WP Admin UI Customize ===
Contributors: gqevu6bsiz
Donate link: http://gqevu6bsiz.chicappa.jp/please-donation/?utm_source=wporg&utm_medium=donate&utm_content=wauc&utm_campaign=1_3_7.1
Tags: admin, post, posts, page, option, sitemenu, menu, custom, customize, dashboard, admin_bar
Requires at least: 3.4.2
Tested up to: 3.5.2
Stable tag: 1.3.7.1
License: GPL2

Customize the management screen UI.

== Description ==

* Dashboard
* Display options tab
* Output-meta site
* Admin bar
* Admin menu (Side menu)
* Management of meta box
* Login screen

These to Customization is possible.

== Installation ==

1. Upload the entire wp-admin-ui-customize folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. You will find 'WP Admin UI Customize' menu in your WordPress admin panel.

== Frequently Asked Questions ==

= A question that someone might have =

= What about foo bar? =

== Screenshots ==

1. Set the user role apply
2. Site Settings
3. Admin Screen Settings
4. Admin Screen Customized
5. Dashboard Settings
6. Dashboard Screen Customized
7. Admin Menu Settings
8. Admin Menu Customized
9. Metabox Settings
10. Login Screen Settings
11. Login Screen Customized

== Changelog ==

= 1.3.7.1 =
* Fixed : Translate.
* Fixed : Misspelling.

= 1.3.7 =
* Added some filters.
* Modified the HTML of some settings screen.
* Changed some initial values of stored in database.
* Added a confirmation of Nonce field.

= 1.3.6 =
* Added the User roles reset.
* Show the User role to Sidemenu.
* Settings of empty when Sidemenu and Admin Bar to change worked.
* Fixed bug : Thumbnail of appearance menu.

= 1.3.5.2 =
* Added the use of variables in the footer text.

= 1.3.5.1 =
* Fixed bug : Get user role group.

= 1.3.5 =
* Changed the action timing of the side menu apply.
* Fixed bug : Can not be acquired rights group.

= 1.3.4 =
* Only administrator has to perform of the Meta boxes read.

= 1.3.3-beta =
* Apply to admin bar on the front end also.
* Edited the translation files.
* Updated the Admin Bar.

= 1.3.3 =
* Fixed bug : Error when deleting plugins and themes.

= 1.3.2 =
* Added meta box other than the default.

= 1.3.1 =
* Added some variables.
* Fixed bug : Error to does not exist sub menu in the side menu settings.
* WordPress 3.6 compatibility

= 1.3 =
* Came to be able to use the various variables.
* Removed the part menu from the Admin bar.

= 1.2.3 =
* Remove the "Wordpress" from the title tag of the Admin screen.
* Added a preview of the logo image of the login screen.
* Added a preview of the logo image of the login screen.

= 1.2.2.2 =
* Fix admin bar menu used the tags in the title.
* Associate add_action to the function of some.
* Movement restriction meta box for Dashboard.

= 1.2.2.1 =
I've added about donation.

= 1.2.2 =
Be able to changed more for the WP admin bar.

= 1.2.1 =
fixed because there was a mistake in the notation.
Changed the layout.
Priority of the side menu, and how to save slug was changed.

= 1.2 =
was be able to hide the menu add, and the delete menu, and the change permalink.

= 1.1.3 =
I fixed bug the remove metabox excerpt.
I added a plug-in information.

= 1.1.2 =
I fixed bug the admin bar update.

= 1.1.1 =
I fixed bug the core update.

= 1.1 =
Possible to customize is the wp_admin_bar.
will check whether the authority has been set.

= 1.0.1 =
bug that did not contain the separator line to the initial value of the side menu.

= 1.0 =
This is the initial release.

== Upgrade Notice ==

= 1.0 =

== 日本語でのご説明 ==

このプラグインは、管理画面UIのカスタマイズをするプラグインです。
「ダッシュボード」「オプションタブ」「サイトのメタタグ管理」「管理バー」「管理メニュー」「メタボックス」「ログイン画面」
これらのカスタマイズを、このプラグインひとつで出来ます。
